"use client";

import { useState, useEffect } from "react";
import { supabase } from "../lib/supabase";

export default function AuthPage({ onAuth }) {
  const [isLogin, setIsLogin] = useState(true);
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState("");

  useEffect(() => {
    // Listen for auth state changes
    const { data: { subscription } } = supabase.auth.onAuthStateChange((event, session) => {
      if (session?.user) {
        onAuth(session.user);
      }
    });

    return () => subscription.unsubscribe();
  }, [onAuth]);

  const handleSubmit = async (e) => {
    e.preventDefault();
    setLoading(true);
    setError("");

    try {
      let result;
      if (isLogin) {
        result = await supabase.auth.signInWithPassword({
          email,
          password,
        });
      } else {
        result = await supabase.auth.signUp({
          email,
          password,
        });
      }

      if (result.error) {
        throw new Error(result.error.message);
      }

      // Auth state change listener will handle onAuth
    } catch (err) {
      setError(err.message);
    } finally {
      setLoading(false);
    }
  };

  return (
    <div style={{
      display: "flex",
      justifyContent: "center",
      alignItems: "center",
      minHeight: "100vh",
      background: "linear-gradient(135deg, #667eea 0%, #764ba2 100%)",
      fontFamily: "Arial, sans-serif"
    }}>
      <div style={{
        background: "white",
        padding: "2rem",
        borderRadius: "10px",
        boxShadow: "0 10px 25px rgba(0,0,0,0.1)",
        width: "100%",
        maxWidth: "400px"
      }}>
        <h1 style={{
          textAlign: "center",
          marginBottom: "2rem",
          color: "#333",
          fontSize: "2rem"
        }}>
          Meeting Scheduler
        </h1>

        <div style={{ textAlign: "center", marginBottom: "1.5rem" }}>
          <button
            onClick={() => setIsLogin(true)}
            style={{
              padding: "0.5rem 1rem",
              margin: "0 0.5rem",
              border: "none",
              borderRadius: "5px",
              background: isLogin ? "#667eea" : "#f0f0f0",
              color: isLogin ? "white" : "#333",
              cursor: "pointer",
              fontSize: "1rem"
            }}
          >
            Login
          </button>
          <button
            onClick={() => setIsLogin(false)}
            style={{
              padding: "0.5rem 1rem",
              margin: "0 0.5rem",
              border: "none",
              borderRadius: "5px",
              background: !isLogin ? "#667eea" : "#f0f0f0",
              color: !isLogin ? "white" : "#333",
              cursor: "pointer",
              fontSize: "1rem"
            }}
          >
            Sign Up
          </button>
        </div>

        <form onSubmit={handleSubmit}>
          <div style={{ marginBottom: "1rem" }}>
            <input
              type="email"
              placeholder="Email"
              value={email}
              onChange={(e) => setEmail(e.target.value)}
              required
              style={{
                width: "100%",
                padding: "0.75rem",
                border: "1px solid #ddd",
                borderRadius: "5px",
                fontSize: "1rem",
                boxSizing: "border-box"
              }}
            />
          </div>

          <div style={{ marginBottom: "1rem" }}>
            <input
              type="password"
              placeholder="Password"
              value={password}
              onChange={(e) => setPassword(e.target.value)}
              required
              style={{
                width: "100%",
                padding: "0.75rem",
                border: "1px solid #ddd",
                borderRadius: "5px",
                fontSize: "1rem",
                boxSizing: "border-box"
              }}
            />
          </div>

          {error && (
            <div style={{
              color: "#e74c3c",
              marginBottom: "1rem",
              fontSize: "0.9rem",
              textAlign: "center"
            }}>
              {error}
            </div>
          )}

          <button
            type="submit"
            disabled={loading}
            style={{
              width: "100%",
              padding: "0.75rem",
              background: "#667eea",
              color: "white",
              border: "none",
              borderRadius: "5px",
              fontSize: "1rem",
              cursor: loading ? "not-allowed" : "pointer",
              opacity: loading ? 0.7 : 1
            }}
          >
            {loading ? "Please wait..." : (isLogin ? "Login" : "Sign Up")}
          </button>
        </form>
      </div>
    </div>
  );
}