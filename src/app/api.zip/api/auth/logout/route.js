import { supabase } from "../../../lib/supabase";

export async function POST() {
  try {
    const { error } = await supabase.auth.signOut();

    if (error) {
      return Response.json(
        { success: false, error: error.message },
        { status: 400 }
      );
    }

    return Response.json({ success: true });

  } catch (err) {
    return Response.json(
      { success: false, error: err.message },
      { status: 500 }
    );
  }
}