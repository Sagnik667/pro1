"use client";

import { useEffect, useRef, useState } from "react";
import { supabase } from "../lib/supabase";
import AuthPage from "./AuthPage";

export default function Page() {
  const containerRef = useRef(null);
  const [user, setUser] = useState(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    // Check if user is authenticated using Supabase
    const checkAuth = async () => {
      try {
        const { data: { session } } = await supabase.auth.getSession();
        if (session?.user) {
          setUser(session.user);
        }
      } catch (err) {
        console.log("Not authenticated");
      } finally {
        setLoading(false);
      }
    };

    checkAuth();

    // Listen for auth changes
    const { data: { subscription } } = supabase.auth.onAuthStateChange((event, session) => {
      if (session?.user) {
        setUser(session.user);
      } else {
        setUser(null);
      }
    });

    return () => subscription.unsubscribe();
  }, []);

  const handleAuth = (userData) => {
    setUser(userData);
  };

  const handleLogout = async () => {
    await supabase.auth.signOut();
    setUser(null);
  };

  // Load app content when user is authenticated
  useEffect(() => {
    if (!user || loading) return;

    // Inject HTML
    fetch("/embed/index.html")
      .then(res => res.text())
      .then(html => {
        if (containerRef.current) {
          containerRef.current.innerHTML = html;

          // Inject script AFTER HTML exists
          const script = document.createElement("script");
          script.src = "/embed/script.js";
          script.defer = true;
          script.onload = async () => {
            // After script loads, pass user and token to it
            const { data: { session } } = await supabase.auth.getSession();
            if (session && window.setAuthData) {
              window.setAuthData(user, session.access_token);
              if (window.loadUserFromDB) await window.loadUserFromDB();
              if (window.loadMeetingsFromDB) await window.loadMeetingsFromDB();
              if (window.renderAll) window.renderAll();
            }
          };
          document.body.appendChild(script);

          // Add logout function to window for the HTML to call
          window.logout = handleLogout;
        }
      });
  }, [user, loading]);

  if (loading) {
    return (
      <div style={{
        display: "flex",
        justifyContent: "center",
        alignItems: "center",
        minHeight: "100vh",
        fontSize: "1.2rem"
      }}>
        Loading...
      </div>
    );
  }

  if (!user) {
    return <AuthPage onAuth={handleAuth} />;
  }

  return <div ref={containerRef} />;
}
